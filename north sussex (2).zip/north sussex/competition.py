from tkinter import *
from PIL import Image,ImageTk
from tkinter import ttk
import random
from time import strftime
from datetime import datetime
import mysql.connector
from tkinter import messagebox

class competition:
    def __init__(self,root) :
        self.root=root
        self.root.title("Colourz Database Management System")
        self.root.geometry("1295x550+230+220")

        #==================Title===================
        lbl_title=Label(self.root,text="COMPETITION DETAILS",font=("Times New Roman",18,"bold"),bg="#006666",fg="white")
        lbl_title.place(x=0,y=0,width=1295,height=50)

        #==================label frame============
        labelframeleft=LabelFrame(self.root,bd=2,relief=RIDGE,text="New Products",font=("Times New Roman",12,"bold"),padx=2)
        labelframeleft.place(x=5,y=50,width=540,height=490)

         #=================labels and entries========
        #name
        lblName=Label(labelframeleft,text="Name : ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lblName.grid(row=0,column=0,sticky=W)
        
        self.var_Name=StringVar()
        entry_Name=ttk.Entry(labelframeleft,textvariable=self.var_Name,width=29,font=("Times New Roman",12,"bold"))
        entry_Name.grid(row=0,column=1,sticky=W)

        #date
        lblDate=Label(labelframeleft,text="Date : ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lblDate.grid(row=1,column=0,sticky=W)
        
        self.var_Date=StringVar()
        entry_Date=ttk.Entry(labelframeleft,textvariable=self.var_Date,width=29,font=("Times New Roman",12,"bold"))
        entry_Date.grid(row=1,column=1,sticky=W)

        #venue
        lblvenue=Label(labelframeleft,text="Venue: ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lblvenue.grid(row=2,column=0,sticky=W)
        
        self.var_venue=StringVar()
        entry_venue=ttk.Entry(labelframeleft,textvariable=self.var_venue,width=29,font=("Times New Roman",12,"bold"))
        entry_venue.grid(row=2,column=1,sticky=W)

        #prd Des
        lblweight=Label(labelframeleft,text="weight_category: ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lblweight.grid(row=3,column=0,sticky=W)

        self.var_weight=StringVar()
        entry_weight=ttk.Entry(labelframeleft,textvariable=self.var_weight,width=29,font=("Times New Roman",12,"bold"))
        entry_weight.grid(row=3,column=1,sticky=W)

        #========================Button======================
        btn_frame=Frame(labelframeleft,bd=2,relief=RIDGE)
        btn_frame.place(x=0,y=400,width=412,height=40)

        btnADD=Button(btn_frame,text="ADD",command=self.add_data,font=("Times New Roman",12,"bold"),bg="black",fg="gold",width=10)
        btnADD.grid(row=0,column=0,padx=1)

        btnUpdate=Button(btn_frame,text="UPDATE",command=self.update,font=("Times New Roman",12,"bold"),bg="black",fg="gold",width=10)
        btnUpdate.grid(row=0,column=1,padx=1)

        btnDelete=Button(btn_frame,text="DELETE",command=self.mDelete,font=("Times New Roman",12,"bold"),bg="black",fg="gold",width=10)
        btnDelete.grid(row=0,column=2,padx=1)

        btnReset=Button(btn_frame,text="RESET",command=self.reset_data,font=("Times New Roman",12,"bold"),bg="black",fg="gold",width=10)
        btnReset.grid(row=0,column=3,padx=1)

        #==================label frame============
        Table_Frame=LabelFrame(self.root,bd=2,relief=RIDGE,text="Competition Details",font=("Times New Roman",12,"bold"),padx=2)
        Table_Frame.place(x=550,y=50,width=740,height=490)

        #=============show data table================

        scroll_x=ttk.Scrollbar(Table_Frame,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(Table_Frame,orient=VERTICAL)

        self.competition_Table=ttk.Treeview(Table_Frame,column=("Name","Date","venue","weight_category"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.competition_Table.xview)
        scroll_y.config(command=self.competition_Table.yview)

        self.competition_Table.heading("Name",text="Name")
        self.competition_Table.heading("Date",text="Date")
        self.competition_Table.heading("venue",text="venue")
        self.competition_Table.heading("weight_category",text="weight_category")
        

        self.competition_Table["show"]="headings"
        
        self.competition_Table.column("Name",width=150)
        self.competition_Table.column("Date",width=100)
        self.competition_Table.column("venue",width=150)
        self.competition_Table.column("weight_category",width=300)
        
        self.competition_Table.pack(fill=BOTH,expand=1)
        self.competition_Table.bind("<ButtonRelease-1>",self.get_cuersor)
        self.fetch_data()

    
#add data=========
    def add_data(self):
        if self.var_Name.get()=="" or self.var_Date.get()=="" :
            messagebox.showerror("Error","All fields are Required to be Filled",parent=self.root)
        else:
            try:
                        conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
                        my_cursor=conn.cursor()
                        my_cursor.execute("insert into competition values(%s,%s,%s,%s)",(
                                                                                                self.var_Name.get(),
                                                                                                self.var_Date.get(),
                                                                                                self.var_venue.get(),
                                                                                                self.var_weight.get(),
                                                                                                
                                                                                                        ))
                        conn.commit()
                        self.fetch_data()
                        conn.close()
                        messagebox.showinfo("Success","Competition Details have been Added ",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning",f"Something went wrong:{str(es)}",parent=self.root)


#========Fetch data
    def fetch_data(self):
         conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
         my_cursor=conn.cursor()
         my_cursor.execute("select * from competition")
         rows=my_cursor.fetchall()
         if len(rows)!=0:
              self.competition_Table.delete(*self.competition_Table.get_children())
              for i in rows:
                   self.competition_Table.insert("",END,values=i)
              conn.commit()
         conn.close()


    #get cursor========
    def get_cuersor(self,event=""):
         cusrsor_row=self.competition_Table.focus()
         content=self.competition_Table.item(cusrsor_row)
         row=content["values"]

         self.var_Name.set(row[0]),
         self.var_Date.set(row[1]),
         self.var_venue.set(row[2]),
         self.var_weight.set(row[3]),

#update================
    def update(self):
        if self.var_Name.get()=="":
             messagebox.showerror("Error","Please Enter Product ID",parent=self.root)
        else:
             conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
             my_cursor=conn.cursor()
             my_cursor.execute("update competition set Date=%s,venue=%s,weight_category=%s where Name=%s ",(
                                                                                                                                                        self.var_Date.get(),
                                                                                                                                                        self.var_venue.get(),
                                                                                                                                                        self.var_weight.get(),
                                                                                                                                                        self.var_Name.get(),
                                                                                                                                                        
                                                                                                                                                                                        ))
             conn.commit()
             self.fetch_data()
             conn.close()
             messagebox.showinfo("Update","Competition Details has been Updated Successfully",parent=self.root) 


#delete================
    def mDelete(self):
        try:
            mDelete = messagebox.askyesno("Database Management System", "Are You Sure You want to Delete this details?", parent=self.root)
            if mDelete:
                conn = mysql.connector.connect(host="localhost", username="root", password="@Missmystery22", database="judo")
                my_cursor = conn.cursor()
                query = "DELETE FROM competition WHERE Name = %s"
                value = (self.var_Name.get(),)
                my_cursor.execute(query, value)
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success", "Competition Details have been deleted successfully", parent=self.root)
        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"An error occurred: {err}", parent=self.root)


    def reset_data(self):
         self.var_Name.set(""),
         self.var_Date.set(""),
         self.var_venue.set(""),
         self.var_weight.set(""),



if __name__ =="__main__":
    root=Tk()
    obj=competition(root)
    root.mainloop()