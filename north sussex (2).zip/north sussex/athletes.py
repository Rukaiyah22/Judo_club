from tkinter import *
from PIL import Image,ImageTk
from tkinter import ttk
import random
import mysql.connector
from tkinter import messagebox

class Athlete_Win:
    def __init__(self,root) :
        self.root=root
        self.root.title("North Sussex")
        self.root.geometry("1295x550+230+220")

#=================variable=================        
        self.var_Athlete_ID=StringVar()
        x=random.randint(1000,9999)
        self.var_Athlete_ID.set(str(x))

        self.var_Name=StringVar()
        self.var_Gender=StringVar()
        self.var_Address=StringVar()
        self.var_Postcode=StringVar()
        self.var_NIC=StringVar()
        self.var_Pending_Payments=StringVar()
        self.var_Contactno=StringVar()
        self.var_Email=StringVar()
        self.var_training=StringVar()
        self.var_Fees=StringVar()
#==================Title===================
        lbl_title=Label(self.root,text="ATHLETES DETAILS",font=("Times New Roman",18,"bold"),bg="#006666",fg="white")
        lbl_title.place(x=0,y=0,width=1295,height=50)

#==================label frame============
        labelframeleft=LabelFrame(self.root,bd=2,relief=RIDGE,text="Athlete Personal Info",font=("Times New Roman",12,"bold"),padx=2)
        labelframeleft.place(x=5,y=50,width=425,height=490)

#=================labels and entries========
        #Customer ID
        lbl_cust_ID=Label(labelframeleft,text="Athlete_ID : ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lbl_cust_ID.grid(row=0,column=0,sticky=W)

        entry_ID=ttk.Entry(labelframeleft,textvariable=self.var_Athlete_ID,width=29,font=("Times New Roman",12,"bold"),state="readonly")
        entry_ID.grid(row=0,column=1)

        #name
        cname=Label(labelframeleft,text="Athlete_Name : ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        cname.grid(row=1,column=0,sticky=W)

        entry_ID=ttk.Entry(labelframeleft,textvariable=self.var_Name,width=29,font=("Times New Roman",12,"bold"))
        entry_ID.grid(row=1,column=1)

        #Gender
        lbl_gender=Label(labelframeleft,text="Gender : ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lbl_gender.grid(row=2,column=0,sticky=W)
        combo_gender=ttk.Combobox(labelframeleft,textvariable=self.var_Gender,font=("Times New Roman",11,"bold"),width=27,state="readonly")
        combo_gender["value"]=("Male","Female","Other")
        combo_gender.current(0)
        combo_gender.grid(row=2,column=1)


        #address
        lbladdress=Label(labelframeleft,font=("Times New Roman",11,"italic"),text="Address : ",padx=2,pady=6)
        lbladdress.grid(row=3,column=0,sticky=W)
        txtaddress=ttk.Entry(labelframeleft,textvariable=self.var_Address,font=("Times New Roman",12,"bold"),width=29)
        txtaddress.grid(row=3,column=1)

        #postCode
        lblPostCode=Label(labelframeleft,font=("Times New Roman",11,"italic"),text="Postal_Code : ",padx=2,pady=6)
        lblPostCode.grid(row=4,column=0,sticky=W)
        txtPostCode=ttk.Entry(labelframeleft,textvariable=self.var_Postcode,font=("Times New Roman",12,"bold"),width=29)
        txtPostCode.grid(row=4,column=1)

        #NIC
        lblNIC=Label(labelframeleft,font=("Times New Roman",11,"italic"),text="NIC no : ",padx=2,pady=6)
        lblNIC.grid(row=5,column=0,sticky=W)
        txtNIC=ttk.Entry(labelframeleft,textvariable=self.var_NIC,font=("Times New Roman",12,"bold"),width=29)
        txtNIC.grid(row=5,column=1)
        #pending
        lblPending_Payments=Label(labelframeleft,font=("Times New Roman",11,"italic"),text="Pending Payments : ",padx=2,pady=6)
        lblPending_Payments.grid(row=6,column=0,sticky=W)
        txtPending_Payments=ttk.Entry(labelframeleft,textvariable=self.var_Pending_Payments,font=("Times New Roman",12,"bold"),width=29)
        txtPending_Payments.grid(row=6,column=1)


        #mobile number
        lblmobile=Label(labelframeleft,font=("Times New Roman",11,"italic"),text="Contact No : ",padx=2,pady=6)
        lblmobile.grid(row=7,column=0,sticky=W)
        txtmobile=ttk.Entry(labelframeleft,textvariable=self.var_Contactno,font=("Times New Roman",12,"bold"),width=29)
        txtmobile.grid(row=7,column=1)

        #email
        lblEmail=Label(labelframeleft,font=("Times New Roman",11,"italic"),text="E-mail : ",padx=2,pady=6)
        lblEmail.grid(row=8,column=0,sticky=W)
        txtEmail=ttk.Entry(labelframeleft,textvariable=self.var_Email,font=("Times New Roman",12,"bold"),width=29)
        txtEmail.grid(row=8,column=1)

        #Training
        lbl_training=Label(labelframeleft,text="Training plan: ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lbl_training.grid(row=9,column=0,sticky=W)
        combo_training=ttk.Combobox(labelframeleft,textvariable=self.var_training,font=("Times New Roman",11,"bold"),width=27,state="readonly")
        combo_training["value"]=("Foundation","Technique Development","Randori","Pre-comp","Special Training","Master")
        combo_training.current(0)
        combo_training.grid(row=9,column=1)

        #fee
        lblFees=Label(labelframeleft,font=("Times New Roman",11,"italic"),text="To Be Paid : ",padx=2,pady=6)
        lblFees.grid(row=10,column=0,sticky=W)
        txtFees=ttk.Entry(labelframeleft,textvariable=self.var_Fees,font=("Times New Roman",12,"bold"),width=29)
        txtFees.grid(row=10,column=1)

        btnFee=Button(labelframeleft,text="Fee",command=self.calculate_fee,font=("Times New Roman",12,"bold"),bg="white",fg="#006666",width=10)
        btnFee.grid(row=15,column=0,padx=3,pady=4,sticky=W)

        #========================Button======================
        btn_frame=Frame(labelframeleft,bd=2,relief=RIDGE)
        btn_frame.place(x=2,y=420,width=412,height=40)

        btnADD=Button(btn_frame,text="ADD",command=self.add_data,font=("Times New Roman",12,"bold"),bg="white",fg="#006666",width=10)
        btnADD.grid(row=0,column=0,padx=1)

        btnUpdate=Button(btn_frame,text="UPDATE",command=self.update,font=("Times New Roman",12,"bold"),bg="white",fg="#006666",width=10)
        btnUpdate.grid(row=0,column=1,padx=1)

        btnDelete=Button(btn_frame,text="DELETE",command=self.mDelete,font=("Times New Roman",12,"bold"),bg="white",fg="#006666",width=10)
        btnDelete.grid(row=0,column=2,padx=1)

        btnReset=Button(btn_frame,text="RESET",command=self.reset,font=("Times New Roman",12,"bold"),bg="white",fg="#006666",width=10)
        btnReset.grid(row=0,column=3,padx=1)

        #===================table frame=====================
        Table_frame=LabelFrame(self.root,bd=2,relief=RIDGE,text="View Details and Search System",font=("Times New Roman",12,"bold"),padx=2)
        Table_frame.place(x=435,y=50,width=860,height=490)

        lblSearchBy=Label(Table_frame,font=("Times New Roman",11,"bold"),text="Search By ",bg="maroon",fg="white",width=11)
        lblSearchBy.grid(row=0,column=0,sticky=W,padx=1)

        self.search_var=StringVar()
        combo_Search=ttk.Combobox(Table_frame,textvariable=self.search_var,font=("Times New Roman",11),width=24,state="readonly")
        combo_Search["value"]=("Athlete_ID","Contact_no")
        combo_Search.current(0)
        combo_Search.grid(row=0,column=1,padx=1)

        self.txt_search=StringVar()
        txtSearch=ttk.Entry(Table_frame,textvariable=self.txt_search,font=("Times New Roman",11,"bold"),width=24)
        txtSearch.grid(row=0,column=2,padx=1)

        btnSearch=Button(Table_frame,text="Search",command=self.search,font=("Times New Roman",11,"italic"),bg="maroon",fg="white",width=11)
        btnSearch.grid(row=0,column=3,padx=1)

        btnShowAll=Button(Table_frame,text="Show",command=self.fetch_data,font=("Times New Roman",11,"italic"),bg="maroon",fg="white",width=11)
        btnShowAll.grid(row=0,column=4,padx=1)

        #=============show data table================
        details_table=Frame(Table_frame,bd=2,relief=RIDGE)
        details_table.place(x=0,y=50,width=850,height=350)

        scroll_x=ttk.Scrollbar(details_table,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(details_table,orient=VERTICAL)

        self.Athlete_Table=ttk.Treeview(details_table,column=("Athlete_ID","Name","Gender","Address","Post Code","NIC","Pending_Payments","Contact no","E-mail","Training plan","To be Paid"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.Athlete_Table.xview)
        scroll_y.config(command=self.Athlete_Table.yview)

        self.Athlete_Table.heading("Athlete_ID",text="Athlete_ID")
        self.Athlete_Table.heading("Name",text="Name")
        self.Athlete_Table.heading("Gender",text="Gender")
        self.Athlete_Table.heading("Address",text="Address")
        self.Athlete_Table.heading("Post Code",text="Post Code")
        self.Athlete_Table.heading("NIC",text="NIC")
        self.Athlete_Table.heading("Pending_Payments",text="Pending_Payments")
        self.Athlete_Table.heading("Contact no",text="Contact no")
        self.Athlete_Table.heading("E-mail",text="E-mail")
        self.Athlete_Table.heading("Training plan",text="Training Plan")
        self.Athlete_Table.heading("To be Paid",text="To be Paid")

        self.Athlete_Table["show"]="headings"

        self.Athlete_Table.column("Athlete_ID",width=100)
        self.Athlete_Table.column("Name",width=100)
        self.Athlete_Table.column("Gender",width=100)
        self.Athlete_Table.column("Address",width=200)
        self.Athlete_Table.column("Post Code",width=100)
        self.Athlete_Table.column("NIC",width=150)
        self.Athlete_Table.column("Pending_Payments",width=150)
        self.Athlete_Table.column("Contact no",width=100)
        self.Athlete_Table.column("E-mail",width=150)
        self.Athlete_Table.column("Training plan",width=150)
        self.Athlete_Table.column("To be Paid",width=150)


        self.Athlete_Table.pack(fill=BOTH,expand=1)
        self.Athlete_Table.bind("<ButtonRelease-1>",self.get_cuersor)
        self.fetch_data()

    def add_data(self):
        if self.var_Contactno.get()=="" or self.var_Name.get()=="" :
            messagebox.showerror("Error","All fields are Required to be Filled",parent=self.root)
        else:
            try:
                        conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
                        my_cursor=conn.cursor()
                        my_cursor.execute("insert into athlete values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(
                                                                                                self.var_Athlete_ID.get(),
                                                                                                self.var_Name.get(),
                                                                                                self.var_Gender.get(),
                                                                                                self.var_Address.get(),
                                                                                                self.var_Postcode.get(),
                                                                                                self.var_NIC.get(),
                                                                                                self.var_Pending_Payments.get(),
                                                                                                self.var_Contactno.get(),
                                                                                                self.var_Email.get(),
                                                                                                self.var_training.get(),
                                                                                                self.var_Fees.get(),
                                                                                                        ))
                        conn.commit()
                        self.fetch_data()
                        conn.close()
                        messagebox.showinfo("Success","New Athlete Details have been Added ",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning",f"Something went wrong:{str(es)}",parent=self.root)
    def fetch_data(self):
         conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
         my_cursor=conn.cursor()
         my_cursor.execute("select * from athlete")
         rows=my_cursor.fetchall()
         if len(rows)!=0:
              self.Athlete_Table.delete(*self.Athlete_Table.get_children())
              for i in rows:
                   self.Athlete_Table.insert("",END,values=i)
              conn.commit()
         conn.close() 

    def get_cuersor(self,event=""):
         cusrsor_row=self.Athlete_Table.focus()
         content=self.Athlete_Table.item(cusrsor_row)
         row=content["values"]

         self.var_Athlete_ID.set(row[0]),
         self.var_Name.set(row[1]),
         self.var_Gender.set(row[2]),
         self.var_Address.set(row[3]),
         self.var_Postcode.set(row[4]),
         self.var_NIC.set(row[5]),
         self.var_Pending_Payments.set(row[6]),
         self.var_Contactno.set(row[7]),
         self.var_Email.set(row[8]),
         self.var_training.set(row[9]),
         self.var_Fees.set(row[10])

    def update(self):
        if self.var_Contactno.get()=="":
             messagebox.showerror("Error","Please Enter Mobile Number",parent=self.root)
        else:
             conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
             my_cursor=conn.cursor()
             my_cursor.execute("update athlete set Name=%s,Gender=%s,Address=%s,Postal_Code=%s,NIC=%s,Pending_Payments=%s,Contactno=%s,Email=%s,training=%s,Fees=%s where Athlete_ID=%s",(
                                                                                                                                                        self.var_Name.get(),
                                                                                                                                                        self.var_Gender.get(),
                                                                                                                                                        self.var_Address.get(),
                                                                                                                                                        self.var_Postcode.get(),
                                                                                                                                                        self.var_NIC.get(),
                                                                                                                                                        self.var_Pending_Payments.get(),
                                                                                                                                                        self.var_Contactno.get(),
                                                                                                                                                        self.var_Email.get(),
                                                                                                                                                        self.var_training.get(),
                                                                                                                                                        self.var_Fees.get(),
                                                                                                                                                        self.var_Athlete_ID.get()
                                                                                                                                                                                        ))
             conn.commit()
             self.fetch_data()
             conn.close()
             messagebox.showinfo("Update","Athlete Details has been Updated Successfully",parent=self.root)

    def mDelete(self):
         mDelete=messagebox.askyesno("Database Management System","Are You Sure You want to Delete this Athlete details?",parent=self.root)
         if mDelete>0:
             conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
             my_cursor=conn.cursor()
             query="delete from athlete where Athlete_ID=%s"
             value=(self.var_Athlete_ID.get(),)
             my_cursor.execute(query,value)
         else:
              if not mDelete:
                   return
         
         conn.commit()
         self.fetch_data()
         conn.close()

    def reset(self):
         #self.var_Athlete_ID.set(""),
         self.var_Name.set(""),
         #self.var_Gender.set(""),
         self.var_Address.set(""),
         self.var_Postcode.set(""),
         self.var_NIC.set(""),
         self.var_Contactno.set(""),
         self.var_Email.set(""),
         self.var_Pending_Payments.set("")
         self.var_training.set("")
         self.var_Fees.set("")
         
         x=random.randint(1000,9999)
         self.var_Athlete_ID.set(str(x))

    def search(self):
     try:
          conn = mysql.connector.connect(host="localhost", username="root", password="@Missmystery22", database="judo")
          my_cursor = conn.cursor()

          search_criteria = self.search_var.get()
          search_value = self.txt_search.get()

          if search_criteria and search_value:
               query = f"SELECT * FROM athlete WHERE {search_criteria} LIKE '%{search_value}%'"
               my_cursor.execute(query)
               rows = my_cursor.fetchall()

               if len(rows) != 0:
                    self.Athlete_Table.delete(*self.Athlete_Table.get_children())
                    for i in rows:
                         self.Athlete_Table.insert("", END, values=i)
                    conn.commit()
               else:
                    messagebox.showinfo("Info", "No matching records found.", parent=self.root)
          else:
               messagebox.showerror("Error", "Please select a search criteria and enter a search term.", parent=self.root)
     except Exception as e:
          messagebox.showerror("Error", f"Error fetching data: {str(e)}", parent=self.root)
     finally:
          conn.close()



##=====================================================fee calc==================================
    def calculate_fee(self):
     selected_training = self.var_training.get()

     if selected_training:

          try:
               conn = mysql.connector.connect(host="localhost", username="root", password="@Missmystery22", database="judo")
               my_cursor = conn.cursor()
               my_cursor.execute("SELECT Fees FROM Trainings WHERE training = %s", (selected_training,))
               row = my_cursor.fetchone()

               if row:
                    training_fee = float(row[0])
                    pending_payment = float(self.var_Pending_Payments.get())
                    total_fee = pending_payment + training_fee
                    self.var_Fees.set(total_fee)
               else:
                    messagebox.showerror("Error", f"Fee for '{selected_training}' not found in the database", parent=self.root)
          except Exception as e:
               messagebox.showerror("Error", f"Error fetching data: {str(e)}", parent=self.root)
          finally:
               conn.close()
     else:
          messagebox.showerror("Error", "Please select a Training Plan", parent=self.root)




       
if __name__ =="__main__":
    root=Tk()
    obj=Athlete_Win(root)
    root.mainloop()
