from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
from athletes import Athlete_Win
from selection import selection
from competition import competition

def main():
    win=Tk()
    app=Login_window(win)
    win.mainloop()


class Login_window:
    def __init__(self,root):
        self.root=root
        self.root.title("Login")
        self.root.geometry("1400x700+55+55")
        self.var_email=StringVar()
        self.var_password=StringVar()

        self.bg=ImageTk.PhotoImage(file=r"images\5.jpg")

        lbl_bg=Label(self.root,image=self.bg)
        lbl_bg.place(x=0,y=0,relwidth=1,relheight=1)

        frame=Frame(self.root,bg="black")
        frame.place(x=50,y=260,width=600,height=390)

        

        #####=========header==========
        lbl_title=Label(self.root,text="Welcome to North Sussex Judo Acadamy",font=("Times New Roman",50,"bold"),bg="black",fg="white")
        lbl_title.place(x=0,y=0,width=1400,height=80)

        ### =========frame============

        img1=Image.open(r"images\login.png")
        img1=img1.resize((100,130),Image.ANTIALIAS)
        self.photoimage1=ImageTk.PhotoImage(img1)
        lbl_img1=Label(image=self.photoimage1,bg="black",borderwidth=0,)
        lbl_img1.place(x=400,y=280,width=100,height=130)

        get_str=Label(frame,text="Login to Proceed",font=("times new roman",24,"bold"),fg="white",bg="black")
        get_str.place(x=92,y=70)

        ###=======label===============
        username_lbl=Label(frame,text="User Name",font=("times new roman",13,"bold"),fg="white",bg="black")
        username_lbl.place(x=90,y=130)

        self.txtuser=ttk.Entry(frame,font=("times new roman",13,"bold"),)
        self.txtuser.place(x=56,y=160,width=400)

        password_lbl=Label(frame,text="Password",font=("times new roman",13,"bold"),fg="white",bg="black")
        password_lbl.place(x=90,y=205)

        self.txtpassword=ttk.Entry(frame,font=("times new roman",13,"bold"),)
        self.txtpassword.place(x=53,y=234,width=400)


        #####========icon images========
        img2=Image.open(r"C:\Users\DELL\OneDrive\Desktop\Database attempt 2\images\user.png")
        img2=img2.resize((26,26),Image.ANTIALIAS)
        self.photoimage2=ImageTk.PhotoImage(img2)
        lbl_img2=Label(image=self.photoimage2,bg="black",borderwidth=0)
        lbl_img2.place(x=110,y=390,width=26,height=26)

        img3=Image.open(r"C:\Users\DELL\OneDrive\Desktop\Database attempt 2\images\pass.png")
        img3=img3.resize((24,24),Image.ANTIALIAS)
        self.photoimage3=ImageTk.PhotoImage(img3)
        lbl_img3=Label(image=self.photoimage3,bg="black",borderwidth=0)
        lbl_img3.place(x=110,y=463,width=24,height=24)

        ####=============lgnbtn===============
        loginbtn=Button(frame,text="Login",command=self.login,font=("times new roman",16,"bold"),bd=2,relief=RIDGE,fg="white",bg="#1a8cff")
        loginbtn.place(x=335,y=280,width=120,height=35)

        ###==========login btn============
        registerbtn=Button(frame,text="Register New User",command=self.register_window,font=("times new roman",11,"bold"),borderwidth=0,fg="white",bg="black",activebackground="black",activeforeground="white")
        registerbtn.place(x=20,y=270,width=190)

        ###==========forgotpasswordbtn============
        forgotbtn=Button(frame,text="Forgot Password?",command=self.forgot_password_window,font=("times new roman",11,"bold"),borderwidth=0,fg="white",bg="black",activebackground="black",activeforeground="white")
        forgotbtn.place(x=32,y=290,width=156)

    def register_window(self):
        self.new_window=Toplevel(self.root)
        self.app=Register(self.new_window)

    def login(self):
        if self.txtuser.get()=="" or self.txtpassword.get()=="":
            messagebox.showerror("Error","Check if all fields are filled")
        elif self.txtuser.get()=="Anu" and self.txtpassword.get()=="1234":
            messagebox.showinfo("Logged in successfully"," please wait for the database windows to open")
        else:
           conn=mysql.connector.connect(host="localhost",user="root",password="@Missmystery22",database="judo")
           my_cursor=conn.cursor()
           my_cursor.execute("select * from login where email=%s and password=%s",(
                                                                                        self.var_email.get(),
                                                                                        self.var_password.get()    
                                                                                        )) 
           row=my_cursor.fetchone()
           if row!=None:
               messagebox.showerror("Error","Invalid User name or Password")
           else:
               open_main=messagebox.askyesno("YesNo","Access only Admin")
               if open_main:
                self.new_window = Toplevel(self.root)
                self.app =judoapp(self.new_window)  # Ensure the class and constructor exist
               else:
                if not open_main:
                    return
           conn.commit()
           conn.close()



    def reset_pass(self):
        if self.combo_Department.get()=="":
            messagebox.showerror("Error","Select the Department") 
        else:
            conn=mysql.connector.connect(host="localhost",user="root",password="@Missmystery22",database="judo")
            my_cursor=conn.cursor()
            query=("Select * from login where email=%s and Department=%s and depsec=%s")
            value=(self.txtuser.get(),self.combo_Department.get(),)
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()
            if row==None:
                messagebox("Error","Something went Wrong try again")
            else:
                query=("update login set password=%s where email=%s")
                value=(self.txtpassword.get(),self.txtuser.get(),)
                my_cursor.execute(query,value)

                conn.commit()
                conn.close()
                messagebox.showinfo("Success","Password Updated")


    def forgot_password_window(self):
        if self.txtuser.get()=="":
            messagebox.showerror("Error","Enter Email to reset password")
        else:
            conn=mysql.connector.connect(host="localhost",user="root",password="@Missmystery22",database="judo")
            my_cursor=conn.cursor()
            query=("Select * from login where email=%s")
            value=(self.txtuser.get(),)
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()
            #print(row)
            if row==None:
                messagebox.showerror("Error","Please enter valid user name")
            else:
                conn.close()
                self.root2=Toplevel()
                self.root2.title("Forgot Password")
                self.root2.geometry("350x450+610+170")

                l=Label(self.root2,text="Forgot Password",font=("times new roman",15,"bold"),fg="white",bg="black")
                l.place(x=0,y=10,relwidth=1)

                #Department
                Department=Label(self.root2,text="Department",font=("times new roman",15,"bold"),fg="white",bg="darkblue")
                Department.place(x=20,y=80)

                self.combo_Department=ttk.Combobox(self.root2,font=("times new roman",12,"bold"),state="readonly")
                self.combo_Department["values"]=("Marketing","IT and database","Sales","Production","Customer Support","Finance","Quality Control","Management","HR")
                self.combo_Department.place(x=20,y=110,height=28,width=300)
                self.combo_Department.current(0)


                #depsec
                depsec=Label(self.root2,text="Security code of the department",font=("times new roman",15,"bold"),fg="white",bg="darkblue")
                depsec.place(x=20,y=150)

                depsec_entry=ttk.Entry(self.root2,font=("times new roman",14,"bold"))
                depsec_entry.place(x=20,y=180,width=300)

                newpassword=Label(self.root2,text="New Password",font=("times new roman",15,"bold"),fg="white",bg="darkblue")
                newpassword.place(x=20,y=220)

                newpassword_entry=ttk.Entry(self.root2,font=("times new roman",14,"bold"))
                newpassword_entry.place(x=20,y=250,width=300)

                btn=Button(self.root2,text="Reset",font=("times new roman",15,"bold"),fg="white",bg="darkgreen")
                btn.place(x=100,y=290,width=160)

                       



###================================================================================================
#=================================================================================================
#==================================reg============================================================
class Register:
    def __init__(self,root):
        self.root=root
        self.root.title("Register")
        self.root.geometry("1200x700+170+55")

        self.bg=ImageTk.PhotoImage(file=r"C:\Users\DELL\OneDrive\Desktop\north sussex\images\5.jpg")
        
        bglbl=Label(self.root,image=self.bg,bg="black")
        bglbl.place(x=0,y=0,relwidth=1,relheight=1)

        #==============variables===================
        self.var_email=StringVar()
        self.var_fullname=StringVar()
        self.var_password=StringVar()
        self.var_confirmpassword=StringVar()
        self.var_checkbutton=StringVar()



######======main frame====================
        frame=Frame(self.root,bg="black")
        frame.place(x=10,y=140,height=430,width=700)

        register_lbl=Label(frame,text="Get Your New Access Here",font=("times new roman",24,"bold"),fg="white",bg="black")
        register_lbl.place(x=20,y=20)

        #email
        email=Label(frame,text="Email",font=("times new roman",15,"bold"),fg="white",bg="black")
        email.place(x=20,y=120)

        email_entry=ttk.Entry(frame,textvariable=self.var_email,font=("times new roman",14,"bold"))
        email_entry.place(x=20,y=150,width=610)

        ##========entries =================
        #first name
        fname=Label(frame,text="Fullname",font=("times new roman",15,"bold"),fg="white",bg="black")
        fname.place(x=20,y=60)

        fname_entry=ttk.Entry(frame,textvariable=self.var_fullname,font=("times new roman",14,"bold"))
        fname_entry.place(x=20,y=90,width=300)

        #password
        password=Label(frame,text="Password",font=("times new roman",15,"bold"),fg="white",bg="black")
        password.place(x=20,y=190)

        password_entry=ttk.Entry(frame,textvariable=self.var_password,font=("times new roman",14,"bold"))
        password_entry.place(x=20,y=220,width=300)

        #confirmpassword
        confirmpassword=Label(frame,text="Confirm Password",font=("times new roman",15,"bold"),fg="white",bg="black")
        confirmpassword.place(x=350,y=190)

        confirmpassword_entry=ttk.Entry(frame,textvariable=self.var_confirmpassword,font=("times new roman",14,"bold"))
        confirmpassword_entry.place(x=350,y=220,width=230)

        #check btn================
        checkbutton=Checkbutton(frame,text="I Agree with the terms and conditions to store my information",variable=self.var_checkbutton,font=("times new roman",11,"bold"),onvalue=1,offvalue=0)
        checkbutton.place(x=20,y=290)

      #####=====================Buttons================================
        img=Image.open(r"C:\Users\DELL\OneDrive\Desktop\Database attempt 2\images\reg.png")
        img=img.resize((100,100),Image.ANTIALIAS)
        self.photoimage=ImageTk.PhotoImage(img)
        b1=Button(frame,image=self.photoimage,command=self.register_data,borderwidth=0,cursor="hand2",bg="black",activebackground="black")
        b1.place(x=520,y=290,width=100,height=60) 

        img1=Image.open(r"C:\Users\DELL\OneDrive\Desktop\Database attempt 2\images\lgn.png")
        img1=img1.resize((100,40),Image.ANTIALIAS)
        self.photoimage1=ImageTk.PhotoImage(img1)
        b1=Button(frame,image=self.photoimage1,borderwidth=0,cursor="hand2",bg="black",activebackground="black")
        b1.place(x=520,y=350,width=100,height=50) 

        #function declaration==================
    def register_data(self):
        if self.var_fullname.get()=="" or self.var_email.get()=="" :
            messagebox.showerror("Error","All fields are required")
        elif self.var_password.get()!=self.var_confirmpassword.get():
            messagebox.showerror("Error","Password Doesn't Match with the Confirm Password")
        elif self.var_checkbutton.get()==0:
            messagebox.showerror("Error","Agree for the terms and condition to proceed")
        else:
            conn=mysql.connector.connect(host="localhost",user="root",password="@Missmystery22",database="judo")
            my_cursor=conn.cursor()
            query=("select * from login where Email=%s")
            value=(self.var_email.get(),)
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()
            if row!=None:
                messagebox.showerror("Error","User already exist")
            else:
                my_cursor.execute("insert into login values (%s,%s,%s,%s)", (
                                                                                                                                        self.var_fullname.get(),
                                                                                                                                        self.var_email.get(),
                                                                                                                                        self.var_password.get(),
                                                                                                                                        self.var_confirmpassword.get(),
                                                                                                                                
                                                                                                                                    ))

                conn.commit()
                conn.close()
                messagebox.showinfo("Sucessfully New User Registered","Login to Continue")


#====================================================================================================================
#================================================================================================================
#=====================================company======================================================================

class judoapp:
    def __init__(self,root) :
        self.root=root
        self.root.title("North Sussex")
        self.root.geometry("1550x800+0+0")


        img1=Image.open(r"C:\Users\DELL\OneDrive\Desktop\north sussex\images\lg.png")
        img1=img1.resize((800,180),Image.ANTIALIAS)
        self.photoimg1=ImageTk.PhotoImage(img1)

        lblimg=Label(self.root,image=self.photoimg1,bd=4,relief=RIDGE,bg="white")
        lblimg.place(x=0,y=0,width=1550,height=140,)


        #===============Title=============
        lbl_title=Label(self.root,text="North Sussex Judo Solution ",font=("Times New Roman",40,"italic"),bg="#006666",fg="white")
        lbl_title.place(x=0,y=140,width=1550,height=50)


        #==============Main frame========
        main_frame=Frame(self.root,bd=4,relief=RIDGE)
        main_frame.place(x=0,y=190,width=1550,height=620)

        #==============menue========
        lbl_menu=Label(main_frame,text="Home",font=("Times New Roman",20,"bold"),bg="#006666",fg="white")
        lbl_menu.place(x=0,y=215,width=230)

        #============btn Frame======
        btn_frame=Frame(main_frame,bd=4,relief=RIDGE)
        btn_frame.place(x=0,y=250,width=228,height=155)

        ath_btn=Button(btn_frame,text="Athletes",command=self.athletes,width=22,font=("Times New Roman",14,"bold"),bg="#006666",fg="white",bd=0)
        ath_btn.grid(row=0,column=0,pady=1)

        sel_btn=Button(btn_frame,text="Selection",command=self.selection,width=22,font=("Times New Roman",14,"bold"),bg="#006666",fg="white",bd=0)
        sel_btn.grid(row=1,column=0,pady=1)

        comp_btn=Button(btn_frame,text="Competition",command=self.competition,width=22,font=("Times New Roman",14,"bold"),bg="#006666",fg="white",bd=0)
        comp_btn.grid(row=2,column=0,pady=1)

        logout_btn=Button(btn_frame,text="Logout",command=self.logout,width=22,font=("Times New Roman",14,"bold"),bg="#006666",fg="white",bd=0)
        logout_btn.grid(row=4,column=0,pady=1)

        #======================Rightside image==============
        img3=Image.open(r"C:\Users\DELL\OneDrive\Desktop\north sussex\images\4.png")
        img3=img3.resize((1310,590),Image.ANTIALIAS)
        self.photoimg3=ImageTk.PhotoImage(img3)

        lblimg=Label(main_frame,image=self.photoimg3,bd=4,relief=RIDGE)
        lblimg.place(x=225,y=0,width=1310,height=590)

        #=================down images================
        img4=Image.open(r"C:\Users\DELL\OneDrive\Desktop\north sussex\images\1.png")
        img4=img4.resize((230,210),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(img4)

        lblimg=Label(main_frame,image=self.photoimg4,bd=4,relief=RIDGE,bg="black")
        lblimg.place(x=0,y=3,width=230,height=210)

        img5=Image.open(r"C:\Users\DELL\OneDrive\Desktop\north sussex\images\5.png")
        img5=img5.resize((230,190),Image.ANTIALIAS)
        self.photoimg5=ImageTk.PhotoImage(img5)

        lblimg=Label(main_frame,image=self.photoimg5,bd=4,relief=RIDGE)
        lblimg.place(x=0,y=400,width=230,height=190)

    def selection(self):
            self.new_window=Toplevel(self.root)
            self.app=selection( self.new_window)

    def athletes(self):
        self.new_window=Toplevel(self.root)
        self.app=Athlete_Win(self.new_window)

    def competition(self):
        self.new_window=Toplevel(self.root)
        self.app=competition(self.new_window)

    def logout(self):
         self.root.destroy()


        


if __name__=="__main__":
    main()