from tkinter import *
from PIL import Image,ImageTk
from tkinter import ttk
import random
from time import strftime
from datetime import datetime
import mysql.connector
from tkinter import messagebox

class Trainings:
    def __init__(self,root) :
        self.root=root
        self.root.title("North Sussex Judo Solutions")
        self.root.geometry("1295x550+230+220")

        #==================Title===================
        lbl_title=Label(self.root,text="PLANS AND PAYMENTS",font=("Times New Roman",18,"bold"),bg="#006666",fg="white")
        lbl_title.place(x=0,y=0,width=1295,height=50)

        #==================label frame============
        labelframeleft=LabelFrame(self.root,bd=2,relief=RIDGE,text="New Plans",font=("Times New Roman",12,"bold"),padx=2)
        labelframeleft.place(x=5,y=50,width=540,height=490)

         #=================labels and entries========
        #plan
        lbltraining=Label(labelframeleft,text="training : ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lbltraining.grid(row=0,column=0,sticky=W)
        
        self.var_training=StringVar()
        entry_training=ttk.Entry(labelframeleft,textvariable=self.var_training,width=29,font=("Times New Roman",12,"bold"))
        entry_training.grid(row=0,column=1,sticky=W)

        #price
        lblPrice=Label(labelframeleft,text="Fees : ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lblPrice.grid(row=1,column=0,sticky=W)
        
        self.var_Price=StringVar()
        entry_Price=ttk.Entry(labelframeleft,textvariable=self.var_Price,width=29,font=("Times New Roman",12,"bold"))
        entry_Price.grid(row=1,column=1,sticky=W)

        #weight
        lblweight=Label(labelframeleft,text="Weights eligible : ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lblweight.grid(row=2,column=0,sticky=W)
        
        self.var_weight=StringVar()
        entry_weight=ttk.Entry(labelframeleft,textvariable=self.var_weight,width=29,font=("Times New Roman",12,"bold"))
        entry_weight.grid(row=2,column=1,sticky=W)

        #coach
        lblcoach=Label(labelframeleft,text="Coach : ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lblcoach.grid(row=3,column=0,sticky=W)

        self.var_coach=StringVar()
        entry_coach=ttk.Entry(labelframeleft,textvariable=self.var_coach,width=29,font=("Times New Roman",12,"bold"))
        entry_coach.grid(row=3,column=1,sticky=W)

        #========================Button======================
        btn_frame=Frame(labelframeleft,bd=2,relief=RIDGE)
        btn_frame.place(x=0,y=400,width=412,height=40)

        btnADD=Button(btn_frame,text="ADD",command=self.add_data,font=("Times New Roman",12,"bold"),bg="#006666",fg="white",width=10)
        btnADD.grid(row=0,column=0,padx=1)

        btnUpdate=Button(btn_frame,text="UPDATE",command=self.update,font=("Times New Roman",12,"bold"),bg="#006666",fg="white",width=10)
        btnUpdate.grid(row=0,column=1,padx=1)

        btnDelete=Button(btn_frame,text="DELETE",command=self.mDelete,font=("Times New Roman",12,"bold"),bg="#006666",fg="white",width=10)
        btnDelete.grid(row=0,column=2,padx=1)

        btnReset=Button(btn_frame,text="RESET",command=self.reset_data,font=("Times New Roman",12,"bold"),bg="#006666",fg="white",width=10)
        btnReset.grid(row=0,column=3,padx=1)

        #==================label frame============
        Table_Frame=LabelFrame(self.root,bd=2,relief=RIDGE,text="Plan Details",font=("Times New Roman",12,"bold"),padx=2)
        Table_Frame.place(x=550,y=50,width=740,height=490)

        #=============show data table================

        scroll_x=ttk.Scrollbar(Table_Frame,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(Table_Frame,orient=VERTICAL)

        self.training_Table=ttk.Treeview(Table_Frame,column=("training","","weight","Coach"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.training_Table.xview)
        scroll_y.config(command=self.training_Table.yview)

        self.training_Table.heading("training",text="training")
        self.training_Table.heading("",text="")
        self.training_Table.heading("weight",text="weight")
        self.training_Table.heading("Coach",text="Coach")
        

        self.training_Table["show"]="headings"
        
        self.training_Table.column("training",width=150)
        self.training_Table.column("",width=100)
        self.training_Table.column("weight",width=150)
        self.training_Table.column("Coach",width=300)
        
        self.training_Table.pack(fill=BOTH,expand=1)
        self.training_Table.bind("<ButtonRelease-1>",self.get_cuersor)
        self.fetch_data()

    
#add data=========
    def add_data(self):
        if self.var_training.get()=="" or self.var_Price.get()=="" :
            messagebox.showerror("Error","All fields are Required to be Filled",parent=self.root)
        else:
            try:
                        conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
                        my_cursor=conn.cursor()
                        my_cursor.execute("insert into Trainings values(%s,%s,%s,%s)",(
                                                                                                self.var_training.get(),
                                                                                                self.var_Price.get(),
                                                                                                self.var_weight.get(),
                                                                                                self.var_coach.get(),
                                                                                                
                                                                                                        ))
                        conn.commit()
                        self.fetch_data()
                        conn.close()
                        messagebox.showinfo("Success","Plan Details have been Added ",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning",f"Something went wrong:{str(es)}",parent=self.root)


#========Fetch data
    def fetch_data(self):
         conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
         my_cursor=conn.cursor()
         my_cursor.execute("select * from Trainings")
         rows=my_cursor.fetchall()
         if len(rows)!=0:
              self.training_Table.delete(*self.training_Table.get_children())
              for i in rows:
                   self.training_Table.insert("",END,values=i)
              conn.commit()
         conn.close()


    #get cursor========
    def get_cuersor(self,event=""):
         cusrsor_row=self.training_Table.focus()
         content=self.training_Table.item(cusrsor_row)
         row=content["values"]

         self.var_training.set(row[0]),
         self.var_Price.set(row[1]),
         self.var_weight.set(row[2]),
         self.var_coach.set(row[3]),

#update================
    def update(self):
        if self.var_training.get()=="":
             messagebox.showerror("Error","Please Enter training",parent=self.root)
        else:
             conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
             my_cursor=conn.cursor()
             my_cursor.execute("update Trainings set Fees=%s,weight=%s,Coach=%s where training=%s ",(
                                                                                                                                                        self.var_Price.get(),
                                                                                                                                                        self.var_weight.get(),
                                                                                                                                                        self.var_coach.get(),
                                                                                                                                                        self.var_training.get(),
                                                                                                                                                        
                                                                                                                                                                                        ))
             conn.commit()
             self.fetch_data()
             conn.close()
             messagebox.showinfo("Update","Plan Details has been Updated Successfully",parent=self.root) 


#delete================
    def mDelete(self):
         mDelete=messagebox.askyesno("North sussex Judo","Are You Sure You want to Delete this Entry?",parent=self.root)
         if mDelete>0:
             conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
             my_cursor=conn.cursor()
             query="delete from Trainings where training=%s"
             value=(self.var_training.get(),)
             my_cursor.execute(query,value)
         else:
              if not mDelete:
                   return
         
         conn.commit()
         self.fetch_data()
         conn.close()


    def reset_data(self):
         self.var_training.set(""),
         self.var_Price.set(""),
         self.var_weight.set(""),
         self.var_coach.set(""),



if __name__ =="__main__":
    root=Tk()
    obj=Trainings(root)
    root.mainloop()