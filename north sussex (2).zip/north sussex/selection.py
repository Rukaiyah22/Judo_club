from tkinter import *
from PIL import Image,ImageTk
from tkinter import ttk
import random
from time import strftime
from datetime import datetime
import mysql.connector
from tkinter import messagebox

class selection:
    def __init__(self,root) :
        self.root=root
        self.root.title("North Sussex")
        self.root.geometry("1295x550+230+220")

        #=================variables=============
        self.var_Athlete_ID=StringVar()
        self.var_Date=StringVar()
        self.var_Contactno=StringVar()
        self.var_competition=StringVar() 
        self.var_weight=StringVar()
        self.var_Pending_Payment=StringVar()
        self.var_Eligible_status=StringVar()

        #==================Title===================
        lbl_title=Label(self.root,text="Athlete Selection",font=("Times New Roman",18,"bold"),bg="#006666",fg="white")
        lbl_title.place(x=0,y=0,width=1295,height=50)

        #==================label frame============
        labelframeleft=LabelFrame(self.root,bd=2,relief=RIDGE,text="Athlete Details",font=("Times New Roman",12,"bold"),padx=2)
        labelframeleft.place(x=5,y=50,width=425,height=490)

        #=================labels and entries========
        #cust ID
        lblAthlete_ID=Label(labelframeleft,text="Athlete_ID : ",font=("Times New Roman",11,"italic"),padx=2,pady=6)
        lblAthlete_ID.grid(row=0,column=0,sticky=W)

        entry_Athlete_ID=ttk.Entry(labelframeleft,width=20,textvariable=self.var_Athlete_ID,font=("Times New Roman",12,"bold"))
        entry_Athlete_ID.grid(row=0,column=1,sticky=W)

        #fetch data button
        btnFetchData=Button(labelframeleft,command=self.Fetch_Athlete_ID,text="Fetch_Data",font=("Times New Roman",9,"bold"),bg="white",fg="#006666",width=9)
        btnFetchData.place(x=325,y=4)

        #Date
        lblDate=Label(labelframeleft,font=("Times New Roman",11,"italic"),text="Date : ",padx=2,pady=6)
        lblDate.grid(row=1,column=0,sticky=W)
        txtDate=ttk.Entry(labelframeleft,textvariable=self.var_Date,font=("Times New Roman",12,"bold"),width=29)
        txtDate.grid(row=1,column=1)

        #Contact
        lbl_contact=Label(labelframeleft,font=("Times New Roman",11,"italic"),text="Contact_no : ",padx=2,pady=6)
        lbl_contact.grid(row=3,column=0,sticky=W)
        entry_contact=ttk.Entry(labelframeleft,width=29,textvariable=self.var_Contactno,font=("Times New Roman",12,"bold"))
        entry_contact.grid(row=3,column=1)

        #comp
        lblcompetition=Label(labelframeleft,text="Competition : ",font=("times new roman",11,"italic"),padx=2,pady=6)
        lblcompetition.grid(row=4,column=0,sticky=W)
        comcompetition=ttk.Combobox(labelframeleft,textvariable=self.var_competition,font=("times new roman",12,"bold"),width=27)
        comcompetition["values"]=("Grand Slam","IJF","Youth Junior","Youth Talent","Judo Master","Open Mat","Randori","Novice","Special 7")
        comcompetition.grid(row=4,column=1)


        #weight
        lblweight=Label(labelframeleft,text="Weight Category  : ",font=("times new roman",11,"italic"),padx=2,pady=6)
        lblweight.grid(row=5,column=0,sticky=W)
        comweight=ttk.Combobox(labelframeleft,textvariable=self.var_weight,font=("times new roman",12,"bold"),width=27)
        comweight["values"]=("ELW-upto 60kg","HLW-upto 66kg","LW- upto 73kg","HMW- upto 81kg","MW- upto 90kg","HHW- upto 100kg","HW- over 100kg","NW- no limitations in weight")
        comweight.grid(row=5,column=1)

        #total
        lbleligibility=Label(labelframeleft,font=("Times New Roman",11,"italic"),text="Eligibilty : ",padx=2,pady=6)
        lbleligibility.grid(row=10,column=0,sticky=W)
        txteligibility=ttk.Entry(labelframeleft,textvariable=self.var_Eligible_status,font=("Times New Roman",12,"bold"),width=29)
        txteligibility.grid(row=10,column=1)

        

        #==========Find btn=========
        btnFind=Button(labelframeleft,text="Find",command=self.find,font=("Times New Roman",11,"bold"),bg="white",fg="#006666",width=9)
        btnFind.grid(row=11,column=0,padx=1,sticky=W)

        #========================Button======================
        btn_frame=Frame(labelframeleft,bd=2,relief=RIDGE)
        btn_frame.place(x=0,y=400,width=412,height=40)

        btnADD=Button(btn_frame,text="ADD",command=self.add_data,font=("Times New Roman",12,"bold"),bg="white",fg="#006666",width=10)
        btnADD.grid(row=0,column=0,padx=1)

        btnUpdate=Button(btn_frame,text="UPDATE",command=self.update,font=("Times New Roman",12,"bold"),bg="white",fg="#006666",width=10)
        btnUpdate.grid(row=0,column=1,padx=1)

        btnDelete=Button(btn_frame,text="DELETE",command=self.mDelete,font=("Times New Roman",12,"bold"),bg="white",fg="#006666",width=10)
        btnDelete.grid(row=0,column=2,padx=1)

        btnReset=Button(btn_frame,text="RESET",command=self.reset,font=("Times New Roman",12,"bold"),bg="white",fg="#006666",width=10)
        btnReset.grid(row=0,column=3,padx=1)

        #===========Rightside Image===================
        img3=Image.open(r"images\7.png")
        img3=img3.resize((400,400),Image.ANTIALIAS)
        self.photoimg3=ImageTk.PhotoImage(img3)

        lblimg=Label(self.root,image=self.photoimg3,bd=4,relief=RIDGE)
        lblimg.place(x=885,y=55,width=400,height=400)

        #===================table frame=====================
        Table_frame=LabelFrame(self.root,bd=2,relief=RIDGE,text="View Details and Search System",font=("Times New Roman",12,"bold"),padx=2)
        Table_frame.place(x=435,y=280,width=850,height=260)

        lblSearchBy=Label(Table_frame,font=("Times New Roman",11,"bold"),text="Search By ",bg="#661100",fg="white",width=11)
        lblSearchBy.grid(row=0,column=0,sticky=W,padx=1)

        self.search_var=StringVar()
        combo_Search=ttk.Combobox(Table_frame,textvariable=self.search_var,font=("Times New Roman",11),width=24,state="readonly")
        combo_Search["value"]=("Athlete ID","Contact no")
        combo_Search.current(0)
        combo_Search.grid(row=0,column=1,padx=1)

        self.txt_search=StringVar()
        txtSearch=ttk.Entry(Table_frame,textvariable=self.txt_search,font=("Times New Roman",11,"bold"),width=24)
        txtSearch.grid(row=0,column=2,padx=1)

        btnSearch=Button(Table_frame,text="Search",command=self.search,font=("Times New Roman",11,"italic"),bg="maroon",fg="white",width=11)
        btnSearch.grid(row=0,column=3,padx=1)

        btnShowAll=Button(Table_frame,text="Show",command=self.fetch_data,font=("Times New Roman",11,"italic"),bg="maroon",fg="white",width=11)
        btnShowAll.grid(row=0,column=4,padx=1)

         #=============show data table================
        details_table=Frame(Table_frame,bd=2,relief=RIDGE)
        details_table.place(x=0,y=50,width=840,height=185)

        scroll_x=ttk.Scrollbar(details_table,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(details_table,orient=VERTICAL)

        self.selection_Table=ttk.Treeview(details_table,column=("Athlete_ID","Date","Customer_Contact","Competition","Weight_category","Eligibility_Status"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.selection_Table.xview)
        scroll_y.config(command=self.selection_Table.yview)

        self.selection_Table.heading("Athlete_ID",text="Athlete_ID")
        self.selection_Table.heading("Date",text="Date")
        self.selection_Table.heading("Customer_Contact",text="Customer_Contact")
        self.selection_Table.heading("Competition",text="Competition")
        self.selection_Table.heading("Weight_category",text="Weight_category")
        self.selection_Table.heading("Eligibility_Status",text="Eligibility_Status")
        

        self.selection_Table["show"]="headings"
        
        self.selection_Table.column("Athlete_ID",width=150)
        self.selection_Table.column("Date",width=150)
        self.selection_Table.column("Customer_Contact",width=150)
        self.selection_Table.column("Competition",width=200)
        self.selection_Table.column("Weight_category",width=100)
        self.selection_Table.column("Eligibility_Status",width=150)
        
        self.selection_Table.pack(fill=BOTH,expand=1)
        
        self.selection_Table.bind("<ButtonRelease-1>",self.get_cuersor)
        self.fetch_data()


#add data=========
    def add_data(self):
        if self.var_Athlete_ID.get()=="" or self.var_Date.get()=="" :
            messagebox.showerror("Error","All fields are Required to be Filled",parent=self.root)
        else:
            try:
                        conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
                        my_cursor=conn.cursor()
                        my_cursor.execute("insert into selection values(%s,%s,%s,%s,%s,%s)",(
                                                                                                self.var_Athlete_ID.get(),
                                                                                                self.var_Date.get(),
                                                                                                self.var_Contactno.get(),
                                                                                                self.var_competition.get(),
                                                                                                self.var_weight.get(),
                                                                                                self.var_Eligible_status.get()
                                                                                                        ))
                        conn.commit()
                        self.fetch_data()
                        conn.close()
                        messagebox.showinfo("Success"," Details have been Added ",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning",f"Something went wrong:{str(es)}",parent=self.root)

    


#========Fetch data
    def fetch_data(self):
         conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
         my_cursor=conn.cursor()
         my_cursor.execute("select * from selection")
         rows=my_cursor.fetchall()
         if len(rows)!=0:
              self.selection_Table.delete(*self.selection_Table.get_children())
              for i in rows:
                   self.selection_Table.insert("",END,values=i)
              conn.commit()
         conn.close()  

    #get cursor========
    def get_cuersor(self,event=""):
         cusrsor_row=self.selection_Table.focus()
         content=self.selection_Table.item(cusrsor_row)
         row=content["values"]

         self.var_Athlete_ID.set(row[0]),
         self.var_Date.set(row[1]),
         self.var_Contactno.set(row[2]),
         self.var_competition.set(row[3]),
         self.var_weight.set(row[4]),
         self.var_Eligible_status.set(row[5])  


#update================
    def update(self):
        if self.var_Athlete_ID.get()=="":
             messagebox.showerror("Error","Please Enter Athlete_ID",parent=self.root)
        else:
             conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
             my_cursor=conn.cursor()
             my_cursor.execute("update selection set Date=%s,Contactno=%s,competition=%s,weight=%s,Eligible_status=%s where Athlete_ID=%s ",(
                                                                                                                                                        
                                                                                                                                                        self.var_Date.get(),
                                                                                                                                                        self.var_Contactno.get(),
                                                                                                                                                        self.var_competition.get(),
                                                                                                                                                        self.var_weight.get(),
                                                                                                                                                        self.var_Eligible_status.get(),
                                                                                                                                                        self.var_Athlete_ID.get(),
                                                                                                                                                                                        ))
             conn.commit()
             self.fetch_data()
             conn.close()
             messagebox.showinfo("Update"," Details has been Updated Successfully",parent=self.root) 


#delete================
    def mDelete(self):
         mDelete=messagebox.askyesno("North sussex Judo","Are You Sure You want to Delete this Entry?",parent=self.root)
         if mDelete>0:
             conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
             my_cursor=conn.cursor()
             query="delete from selection where Athlete_ID=%s"
             value=(self.var_Athlete_ID.get(),)
             my_cursor.execute(query,value)
         else:
              if not mDelete:
                   return
         
         conn.commit()
         self.fetch_data()
         conn.close()


#reset==================
    def reset(self):
         self.var_Athlete_ID.set(""),
         self.var_Date.set(""),
         self.var_Contactno.set(""),
         self.var_competition.set(""),
         self.var_weight.set(""),
         self.var_Eligible_status.set("")
         

    #===============ALL DATA FETCH=========    
    def Fetch_Athlete_ID(self):
        if self.var_Athlete_ID.get()=="":
            messagebox.showerror("Error","Please Enter a Athlete_ID",parent=self.root)
        else:
             conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
             my_cursor=conn.cursor()
             query=("select Name from athlete where Athlete_ID=%s")
             value=(self.var_Athlete_ID.get(),)
             my_cursor.execute(query,value)
             row=my_cursor.fetchone()

             if row==None:
                 messagebox.showerror("Error","Athlete_ID not found",parent=self.root)
             else:
                 conn.commit()
                 conn.close()

                 showDataframe=Frame(self.root,bd=4,relief=RIDGE,padx=2)
                 showDataframe.place(x=445,y=55,width=440,height=220)

                 lblName=Label(showDataframe,text="Name : ",font=("Times new roman",12,"bold"))
                 lblName.place(x=0,y=0)

                 lbl=Label(showDataframe,text=row,font=("Times new roman",12))
                 lbl.place(x=90,y=0)
                 
                 #gender=====
                 conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
                 my_cursor=conn.cursor()
                 query=("select Gender from athlete where Athlete_ID=%s")
                 value=(self.var_Athlete_ID.get(),)
                 my_cursor.execute(query,value)
                 row=my_cursor.fetchone()

                 lblGender=Label(showDataframe,text="Gender : ",font=("Times new roman",12,"bold"))
                 lblGender.place(x=0,y=26)

                 lbl2=Label(showDataframe,text=row,font=("Times new roman",12))
                 lbl2.place(x=90,y=26)

                 #address
                 conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
                 my_cursor=conn.cursor()
                 query=("select Address from athlete where Athlete_ID=%s")
                 value=(self.var_Athlete_ID.get(),)
                 my_cursor.execute(query,value)
                 row=my_cursor.fetchone()

                 lblAddress=Label(showDataframe,text="Address : ",font=("Times new roman",12,"bold"))
                 lblAddress.place(x=0,y=54)

                 lbl4=Label(showDataframe,text=row,font=("Times new roman",12))
                 lbl4.place(x=90,y=54)


                 #Contact no
                 conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
                 my_cursor=conn.cursor()
                 query=("select Contactno from athlete where Athlete_ID=%s")
                 value=(self.var_Athlete_ID.get(),)
                 my_cursor.execute(query,value)
                 row=my_cursor.fetchone()

                 lblContactno=Label(showDataframe,text="Contact_no : ",font=("Times new roman",12,"bold"))
                 lblContactno.place(x=0,y=84)

                 lbl3=Label(showDataframe,text=row,font=("Times new roman",12))
                 lbl3.place(x=90,y=84)

                 #Email
                 conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
                 my_cursor=conn.cursor()
                 query=("select Email from athlete where Athlete_ID=%s")
                 value=(self.var_Athlete_ID.get(),)
                 my_cursor.execute(query,value)
                 row=my_cursor.fetchone()

                 lblEmail=Label(showDataframe,text="Email : ",font=("Times new roman",12,"bold"))
                 lblEmail.place(x=0,y=110)

                 lbl4=Label(showDataframe,text=row,font=("Times new roman",12))
                 lbl4.place(x=90,y=110)

                 #Pending Payments
                 conn=mysql.connector.connect(host="localhost",username="root",password="@Missmystery22",database="judo")
                 my_cursor=conn.cursor()
                 query=("select Pending_Payments from athlete where Athlete_ID=%s")
                 value=(self.var_Athlete_ID.get(),)
                 my_cursor.execute(query,value)
                 row=my_cursor.fetchone()

                 lblPending_Payments=Label(showDataframe,text="Pending_Due: ",font=("Times new roman",14,"bold"))
                 lblPending_Payments.place(x=0,y=138)

                 lbl5=Label(showDataframe,text=row,font=("Times new roman",14,"bold"))
                 lbl5.place(x=134,y=138)


    #search system=========
    def search(self):
        try:
            conn = mysql.connector.connect(host="localhost", username="root", password="@Missmystery22", database="judo")
            my_cursor = conn.cursor()

            search_criteria = self.search_var.get()
            search_value = self.txt_search.get()

            if search_criteria and search_value:
                query = f"SELECT * FROM selection WHERE {search_criteria} LIKE '%{search_value}%'"
                my_cursor.execute(query)
                rows = my_cursor.fetchall()

                if len(rows) != 0:
                    self.selection_Table.delete(*self.selection_Table.get_children())
                    for i in rows:
                        self.selection_Table.insert("", END, values=i)
                    conn.commit()
                else:
                    messagebox.showinfo("Info", "No matching records found.", parent=self.root)
            else:
                messagebox.showerror("Error", "Please select a search criteria and enter a search term.", parent=self.root)
        except Exception as e:
            messagebox.showerror("Error", f"Error fetching data: {str(e)}", parent=self.root)
        finally:
            conn.close()


    def find(self):
        competition = self.var_competition.get()
        weight_category = self.var_weight.get()
        pending_payments = str(self.var_Pending_Payment.get())

        if (competition == "Grand Slam" and weight_category in ["HHW-upto 100kg", "HW- over 100kg", "Open weight- no limit"]) or \
        (competition == "IJF" and weight_category in ["HMW- upto 81kg", "MW- upto 90kg", "HHW- upto 100kg", "HW- over 100kg", "Open weight- no limit"]) or \
        (competition == "Youth Junior" and weight_category in ["ELW- up to 60kg", "HLW- upto 66kg", "LW- upto 72kg", "HMW- upto 81kg"]) and pending_payments == 0:
            self.var_Eligible_status.set("Eligible")
        else:
            self.var_Eligible_status.set("Not Eligible")


         







if __name__ =="__main__":
    root=Tk()
    obj=selection(root)
    root.mainloop()
