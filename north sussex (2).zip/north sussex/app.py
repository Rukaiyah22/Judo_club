from tkinter import *
from PIL import Image,ImageTk
from athletes import Athlete_Win
from selection import selection
from competition import competition
from training import Trainings




class judoapp:
    def __init__(self,root) :
        self.root=root
        self.root.title("North Sussex")
        self.root.geometry("1550x800+0+0")


        img1=Image.open(r"images\lg.png")
        img1=img1.resize((800,180),Image.ANTIALIAS)
        self.photoimg1=ImageTk.PhotoImage(img1)

        lblimg=Label(self.root,image=self.photoimg1,bd=4,relief=RIDGE,bg="white")
        lblimg.place(x=0,y=0,width=1550,height=140,)


        #===============Title=============
        lbl_title=Label(self.root,text="North Sussex Judo Solution ",font=("Times New Roman",40,"italic"),bg="#006666",fg="white")
        lbl_title.place(x=0,y=140,width=1550,height=50)


        #==============Main frame========
        main_frame=Frame(self.root,bd=4,relief=RIDGE)
        main_frame.place(x=0,y=190,width=1550,height=620)

        #==============menue========
        lbl_menu=Label(main_frame,text="Home",font=("Times New Roman",20,"bold"),bg="#006666",fg="white")
        lbl_menu.place(x=0,y=215,width=230)

        #============btn Frame======
        btn_frame=Frame(main_frame,bd=4,relief=RIDGE)
        btn_frame.place(x=0,y=250,width=228,height=190)

        ath_btn=Button(btn_frame,text="Athletes",command=self.athletes,width=22,font=("Times New Roman",14,"bold"),bg="#006666",fg="white",bd=0)
        ath_btn.grid(row=0,column=0,pady=1)

        sel_btn=Button(btn_frame,text="Selection",command=self.selection,width=22,font=("Times New Roman",14,"bold"),bg="#006666",fg="white",bd=0)
        sel_btn.grid(row=1,column=0,pady=1)

        comp_btn=Button(btn_frame,text="Competition",command=self.competition,width=22,font=("Times New Roman",14,"bold"),bg="#006666",fg="white",bd=0)
        comp_btn.grid(row=2,column=0,pady=1)

        train_btn=Button(btn_frame,text="Training Plans",command=self.training,width=22,font=("Times New Roman",14,"bold"),bg="#006666",fg="white",bd=0)
        train_btn.grid(row=3,column=0,pady=1)

        logout_btn=Button(btn_frame,text="Logout",command=self.logout,width=22,font=("Times New Roman",14,"bold"),bg="#006666",fg="white",bd=0)
        logout_btn.grid(row=4,column=0,pady=1)

        #======================Rightside image==============
        img3=Image.open(r"images\4.png")
        img3=img3.resize((1310,590),Image.ANTIALIAS)
        self.photoimg3=ImageTk.PhotoImage(img3)

        lblimg=Label(main_frame,image=self.photoimg3,bd=4,relief=RIDGE)
        lblimg.place(x=225,y=0,width=1310,height=590)

        #=================down images================
        img4=Image.open(r"images\1.png")
        img4=img4.resize((230,210),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(img4)

        lblimg=Label(main_frame,image=self.photoimg4,bd=4,relief=RIDGE,bg="black")
        lblimg.place(x=0,y=3,width=230,height=210)

        img5=Image.open(r"images\5.png")
        img5=img5.resize((230,190),Image.ANTIALIAS)
        self.photoimg5=ImageTk.PhotoImage(img5)

        lblimg=Label(main_frame,image=self.photoimg5,bd=4,relief=RIDGE)
        lblimg.place(x=0,y=440,width=230,height=150)

    def selection(self):
            self.new_window=Toplevel(self.root)
            self.app=selection( self.new_window)

    def athletes(self):
        self.new_window=Toplevel(self.root)
        self.app=Athlete_Win(self.new_window)

    def competition(self):
        self.new_window=Toplevel(self.root)
        self.app=competition(self.new_window)

    def training(self):
        self.new_window=Toplevel(self.root)
        self.app=Trainings(self.new_window)

    def logout(self):
         self.root.destroy()











if __name__=="__main__":
    root=Tk()
    obj=judoapp(root)
    root.mainloop()